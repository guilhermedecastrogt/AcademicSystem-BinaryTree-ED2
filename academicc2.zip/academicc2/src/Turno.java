public enum Turno {
    MATUTINO, VESPERTINO, NOTURNO
}